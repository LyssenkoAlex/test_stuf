import './scss/index.scss';

import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import Main from './components/Main';

ReactDOM.render(
  <Fragment>

    <Main/>
  </Fragment>, document.getElementById('root'),
);

