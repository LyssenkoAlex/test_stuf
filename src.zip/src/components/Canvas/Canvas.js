// eslint-disable-next-line no-unused-vars
// import './c_style.scss'
import React, { Component, Fragment } from 'react';
import { RecmouseDown, RecmouseMove, RecmouseUp } from '../ToolsBar/rect';
import getMousePos from '../utils/utils';




export default class Canvas extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scale: 15,
      mouse: { x: 0, y: 0 }, // Current mouse position
      mousePrev: { x: 0, y: 0 }, // Last mouse position
    };
    this.context = undefined; // any canvas contxet
    this.canvas = undefined; // HTML main canvas element
    this.drawingCanvas = undefined; // HTML drawing canvas element
    this.draw = false; // Shows whether the current tool draws
  }

  componentDidMount() { // Set canvas elements
    console.log('works*******self*');
    this.canvas = document.getElementById('main-canvas');
    this.drawingCanvas = document.getElementById('drawing-canvas');

    document.body.addEventListener('mousemove', this.onMouseMove.bind(this));
    document.body.addEventListener('mouseup', this.onMouseUp.bind(this));
  }

  setMousePos(x, y) {
    this.setState(state => ({
      mousePrev: {
        x: state.mouse.x,
        y: state.mouse.y,
      },
      mouse: {
        x,
        y,
      },
    }));
  }


  onMouseDown(e) {
    console.log('onMouseDown startProto ', this.context);
    this.draw = true;
    this.context = this.drawingCanvas.getContext('2d'); // Set current context to drawing canvas ctx
    RecmouseDown.bind(this, e)();
    console.log('onMouseDown endProto ', this.context);
  }

  onMouseMove(e) {
    const pos = getMousePos(this.canvas, e);
    this.setMousePos(pos.x, pos.y);
    this.context = this.drawingCanvas.getContext('2d'); // Set current context to drawing canvas ctx
    if (this.draw) {
      RecmouseMove.bind(this, e)();
    }
  }

  onMouseUp(e) {
    if (this.draw) {
      this.draw = false;
      this.context = this.drawingCanvas.getContext('2d'); // Set current context to drawing canvas ctx
      RecmouseUp.bind(this, e)();
    }
  }

  render() {
    const canvasStyle = {
      transform: `scale(${this.state.scale})`, // Set canvas scale to current scale num
      transformOrigin: '0 0',
    };
    const backgroundStyle = {
      width: '512px',
      height: '512px',
    };

    return (
      <div style={{ width: '512px' }} className='workspace'>
        <div style={backgroundStyle} id="main-canvas-container">

          <canvas style={canvasStyle}
                  className="canvas"
                  id="main-canvas"
                  width={this.props.canvasSize}
                  height={this.props.canvasSize}></canvas>
          <canvas style={canvasStyle}
                  className="canvas"
                  id="drawing-canvas"
                  width={this.props.canvasSize}
                  height={this.props.canvasSize}
                  onMouseDown={this.onMouseDown.bind(this)}
          >
          </canvas>
        </div>

      </div>
    );
  }
}
