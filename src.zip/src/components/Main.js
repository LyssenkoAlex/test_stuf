import React, { Component } from 'react';

// Components import
import ToolsBar from './ToolsBar/ToolsBar';

import Canvas from './Canvas/Canvas';

// Tools import
import * as squareTool from './Tools/squareTool';



export default class Main extends Component {

  constructor(props) {
    super(props);
    this.state = {
      canvasSize: 32,
      mouseUpContainer: () => { },
      mouseMoveContainer: () => { },
      mouseDownContainer: () => { },
      activeToolId: 0, // Id of current active tool
    };


    this.setActiveTool = this.setActiveTool.bind(this);
  }

  componentDidMount() {
    this.setActiveTool(0); // Set active tool to pen tool
  }

  setTool(tool) {
    // Assign a tools drawing functions to containers functions, which later will be past to canvas,
    this.setState({
      mouseDownContainer: tool.mouseDown,
      mouseMoveContainer: tool.mouseMove,
      mouseUpContainer: tool.mouseUp,
    });
  }

  setActiveTool() {
    this.setTool(squareTool);
  }

  render() {
    return (
      <main>
        <ToolsBar setActiveTool={this.setActiveTool}
                  activeToolId={this.state.activeToolId}
        />

        <Canvas
          onMouseDown={this.state.mouseDownContainer}
          onMouseMove={this.state.mouseMoveContainer}
          onMouseUp={this.state.mouseUpContainer}
          canvasSize={this.state.canvasSize}/>

      </main>
    );
  }
}
